# Aditya Pachauri — Personal Portfolio

A responsive, single-page personal portfolio built with HTML, CSS, and JavaScript.

## Files
- `index.html` — website content
- `style.css` — layout, colors, responsive design, and animations
- `script.js` — mobile navigation and current year

## Run locally
Open `index.html` in your browser, or open this folder in VS Code and use the Live Server extension.

## Publish with GitHub Pages
1. Create a new **public** repository on GitHub (for example, `aditya-portfolio`).
2. Upload `index.html`, `style.css`, and `script.js` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then click **Save**.
6. Wait a minute or two. GitHub will show the published website URL in the Pages section.

## Before publishing
The project cards and skill list are starter examples. Update them so they accurately describe your real experience and projects. The contact link opens the visitor's email app.
